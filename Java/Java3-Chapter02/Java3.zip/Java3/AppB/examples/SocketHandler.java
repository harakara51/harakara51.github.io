package examples;

public class SocketHandler {
  public static String echo(String host, int port, String input) {
    return input;
  }
}
