package examples;

public class Customer1 {
    String firstName;
    String lastName;
    Account1 acc;
}
