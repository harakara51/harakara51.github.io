package examples;

public class Bank5 {

    public static void main(String[] args) {
        new Customer5("Jim", "Stewart");
        new Customer5("Joan", "Stewart", 500.0);
    }
}
