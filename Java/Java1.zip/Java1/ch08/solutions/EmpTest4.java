package solutions;

public class EmpTest4 {
    public static void main(String[] args) {
        Employee4 e = new Employee4();
        e.setFirstName("Bob");
        e.setLastName("Dobbs");
        e.setSalary(59900.00F);
        e.setId(42);

        e.showEmp();
    }
}
