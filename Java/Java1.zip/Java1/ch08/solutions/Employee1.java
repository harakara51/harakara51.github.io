package solutions;

public class Employee1 {
    public String firstName;
    public String lastName;
    public float salary;
    public int id;
}
