package solutions;

public class EmpTest2 {
    public static void main(String[] args) {
        Employee2 e = new Employee2();
        e.firstName = "Bob";
        e.lastName = "Dobbs";
        e.salary = 59900.00F;
        e.id = 42;

        e.showEmp();
    }
}
