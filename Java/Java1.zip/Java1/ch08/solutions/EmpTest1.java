package solutions;

public class EmpTest1 {
    public static void main(String[] args) {
        Employee1 e = new Employee1();
        e.firstName = "Bob";
        e.lastName = "Dobbs";
        e.salary = 59900.00F;
        e.id = 42;
    }
}
