package solutions;

public class MI {
    public static void main(String[] args) {
        char first = 'D';
        char middle = 'S';
        char last = 'H';

        System.out.println("Initials: " + first + middle + last);
    }
}
