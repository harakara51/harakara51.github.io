package examples;

public enum OS {
    ANDROID, IOS, WINDOWS, BLACKBERRY
}
