package solutions;

public enum Title {
    MANAGER, PROGRAMMER, CEO 
}
