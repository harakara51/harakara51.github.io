package solutions;

public class Calculator {
    public static double add(double n1, double n2) {
        return n1 + n2;
    }

    public static double subtract(double n1, double n2) {
        return n1 - n2;
    }

    public static double multiply(double n1, double n2) {
        return n1 * n2;
    }

    public static double divide(int n1, int n2) {
        return n1 / n2;
    }

    public static double divide(double n1, double n2) {
        return n1 / n2;
    }
}
