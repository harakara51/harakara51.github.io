package examples.rentalcar;

public class Car {
    private String vIN;
    private String tag;

    public String getVIN() {
        return vIN;
    }

    public void setVIN(String vin) {
        vIN = vin;
    }

    public String getLicenseTag() {
        return tag;
    }

    public void setLicenseTag(String t) {
        tag = t;
    }
}
