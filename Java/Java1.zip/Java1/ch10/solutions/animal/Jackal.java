package solutions.animal;

class Jackal {
    String sound;

    public Jackal() {
        sound = "heehee";
    }

    @Override
    public String toString() {
        return sound;
    }
}
