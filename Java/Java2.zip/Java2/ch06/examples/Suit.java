package examples;

public enum Suit {
    HEARTS, SPADES, CLUBS, DIAMONDS
}
