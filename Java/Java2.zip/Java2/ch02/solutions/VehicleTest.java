package solutions;

public class VehicleTest {
    public static void main(String[] args) {
        Vehicle1 atv = new Vehicle1(45, 3);
        Bicycle1 tenSpeed = new Bicycle1(30, 10);

        System.out.println("My atv: " + atv);
        System.out.println("My ten speed: " + tenSpeed);
    }
}
